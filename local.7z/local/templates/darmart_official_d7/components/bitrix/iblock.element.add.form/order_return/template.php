<?
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
/** @var array $arParams */
/** @var array $arResult */
/** @global CMain $APPLICATION */
/** @global CUser $USER */
/** @global CDatabase $DB */
/** @var CBitrixComponentTemplate $this */
/** @var string $templateName */
/** @var string $templateFile */
/** @var string $templateFolder */
/** @var string $componentPath */
/** @var CBitrixComponent $component */
$this->setFrameMode(false);

use Bitrix\Main\Localization\Loc;

if (!empty($arResult["ERRORS"])):?>
    <? ShowError(implode("<br />", $arResult["ERRORS"])) ?>
<?endif;
if ($arResult["MESSAGE"] <> ''):?>
    <? ShowNote($arResult["MESSAGE"]) ?>
<? endif ?>
<div class="card">
    <h1 class="title-page"><?= Loc::getMessage('PAGE_TITLE') ?></h1>
    <p><?= Loc::getMessage('PAGE_NOTE') ?></p>
    <form action="<?= POST_FORM_ACTION_URI ?>" method="post" enctype="multipart/form-data">
        <?= bitrix_sessid_post() ?>
        <input type="hidden" name="PROPERTY[NAME][0]" value="Заявка на возврат">
        <input type="hidden" name="PROPERTY[85][0]" value="<?= $arResult['USER_INFO']['ID'] ?>">
        <input type="hidden" name="PROPERTY[92][0]" value="<?= $arResult['PRODUCT_INFO']['ID'] ?>">

        <h2 class="title-page"><?= Loc::getMessage('ORDER_INFO') ?></h2>

        <div class="form-group required">
            <label class="control-label" for="input-firstname"><?= Loc::getMessage('USER_NAME') ?>:</label>
            <input type="text"
                   name="PROPERTY[86][0]"
                   value="<?= $arResult['USER_INFO']['NAME'] ?>"
                   placeholder="<?= Loc::getMessage('USER_NAME') ?>:"
                   id="input-firstname" class="form-control">
        </div>

        <div class="form-group required">
            <label class="control-label" for="input-lastname"><?= Loc::getMessage('USER_LASTNAME') ?>:</label>
            <input type="text"
                   name="PROPERTY[87][0]"
                   value="<?= $arResult['USER_INFO']['LAST_NAME'] ?>"
                   placeholder="<?= Loc::getMessage('USER_LASTNAME') ?>:"
                   id="input-lastname"
                   class="form-control">
        </div>

        <div class="form-group required">
            <label class=" control-label" for="input-email"><?= Loc::getMessage('USER_EMAIL') ?>:</label>
            <input type="text"
                   name="PROPERTY[88][0]"
                   value="<?= $arResult['USER_INFO']['EMAIL'] ?>"
                   placeholder="<?= Loc::getMessage('USER_EMAIL') ?>:"
                   id="input-email"
                   class="form-control">
        </div>

        <div class="form-group required">
            <label class="control-label" for="input-telephone"><?= Loc::getMessage('USER_PHONE') ?>:</label>
            <input type="text"
                   name="PROPERTY[89][0]"
                   value="<?= $arResult['USER_INFO']['PERSONAL_PHONE'] ?>"
                   placeholder="<?= Loc::getMessage('USER_PHONE') ?>:"
                   id="input-telephone"
                   class="form-control">
        </div>

        <div class="form-group required">
            <label class=" control-label" for="input-order-id"><?= Loc::getMessage('ORDER_ID') ?>:</label>
            <input type="text"
                   name="PROPERTY[90][0]"
                   value="<?= $arResult['ORDER_INFO']['ID'] ?>"
                   placeholder="<?= Loc::getMessage('ORDER_ID') ?>:"
                   id="input-order-id"
                   class="form-control">
        </div>

        <div class="form-group">
            <label class="control-label" for="input-date-ordered"><?= Loc::getMessage('ORDER_DATE') ?>:</label>
            <div class="input-group date">
                <input type="text"
                       name="PROPERTY[91][0][VALUE]"
                       value="<?= $arResult['ORDER_INFO']['DATE'] ?>"
                       placeholder="<?= Loc::getMessage('ORDER_DATE') ?>:"
                       data-date-format="DD.MM.YYYY hh:mm:ss"
                       id="input-date-ordered" class="form-control">

                <span class="input-group-btn">
                    <button type="button" class="btn btn-default"><i class="fa fa-calendar"></i></button>
                </span>
            </div>
        </div>

        <h2 class="title-page"><?= Loc::getMessage('PRODUCT_INFO') ?></h2>

        <div class="form-group required">
            <label class="control-label" for="input-product"><?= Loc::getMessage('PRODUCT_NAME') ?>:</label>
            <input type="text"
                   name="PROPERTY[115][0]"
                   value='<?= $arResult['ORDER_INFO']['BASKET_NAME'] ?>'
                   placeholder="<?= Loc::getMessage('PRODUCT_NAME') ?>:"
                   id="input-product"
                   class="form-control">
        </div>

        <div class="form-group">
            <label class="control-label" for="input-quantity"><?= Loc::getMessage('PRODUCT_NUMBER') ?>:</label>
            <input type="text"
                   name="PROPERTY[116][0]"
                   value="<?= round($arResult['ORDER_INFO']['BASKET_QUANTITY']) ?>"
                   placeholder="<?= Loc::getMessage('PRODUCT_NUMBER') ?>:"
                   id="input-quantity"
                   class="form-control">
        </div>

        <div class="form-group required">
            <label class="control-label"><?= Loc::getMessage('REASON') ?>:</label>
            <div class="radio">
                <label>
                    <input type="radio" name="PROPERTY[93]" value="18">
                    Другое (другая причина), пожалуйста, укажите/приложите подробности
                </label>
            </div>
            <div class="radio">
                <label>
                    <input type="radio" name="PROPERTY[93]" value="19">
                    Ошибочный, пожалуйста, укажите/приложите подробности
                </label>
            </div>
            <div class="radio">
                <label>
                    <input type="radio" name="PROPERTY[93]" value="20">
                    Получен не тот (ошибочный) товар
                </label>
            </div>
            <div class="radio">
                <label>
                    <input type="radio" name="PROPERTY[93]" value="21">
                    Получен/доставлен неисправным (сломанным)
                </label>
            </div>
        </div>

        <div class="form-group required">
            <label class="control-label"><?= Loc::getMessage('UNPACKED') ?>:</label>
            <label class="radio-inline">
                <input type="radio" name="PROPERTY[94]" value="22">
                <?= Loc::getMessage('YES') ?>
            </label>
            <label class="radio-inline">
                <input type="radio" name="PROPERTY[94]" value="23" checked="checked">
                <?= Loc::getMessage('NO') ?>
            </label>
        </div>

        <div class="form-group">
            <label class="control-label" for="input-comment"><?= Loc::getMessage('DESCRIPTION') ?>:</label>
            <textarea name="PROPERTY[95][0]"
                      rows="10"
                      placeholder="<?= Loc::getMessage('DESCRIPTION') ?>:"
                      id="input-comment"
                      class="form-control"></textarea>
        </div>

        <div class="buttons-overflow clearfix">
            <div class="pull-left"><a href="/personal/" class="btn"><?= Loc::getMessage('BACK_BTN') ?></a></div>
            <div class="pull-right">
                <!--
                Мною прочитаны и я даю согласие с документом
                <a
                    href="https://darmart.kz/index.php?route=information/information/agree&amp;information_id=13"
                    class="agree"><b>Условия возврата и гарантии</b></a>
                <input type="checkbox" name="agree" value="1">-->
                <input
                        type="submit"
                        name="iblock_submit"
                        value="<?= Loc::getMessage('SUBMIT_BTN') ?>"
                        class="btn main-btn">
            </div>
        </div>
    </form>
</div>
<script type="text/javascript">
    $(document).ready(function () {
        $('.date').datetimepicker({
            pickTime: false
        });
    })
</script>

<?php if (false): ?>
    <form name="iblock_add" action="<?= POST_FORM_ACTION_URI ?>" method="post" enctype="multipart/form-data">
        <?= bitrix_sessid_post() ?>
        <? if ($arParams["MAX_FILE_SIZE"] > 0): ?><input type="hidden" name="MAX_FILE_SIZE"
                                                         value="<?= $arParams["MAX_FILE_SIZE"] ?>" /><? endif ?>
        <table class="data-table" style="width: 90%">
            <thead>
            <tr>
                <td colspan="2">&nbsp;</td>
            </tr>
            </thead>
            <? if (is_array($arResult["PROPERTY_LIST"]) && !empty($arResult["PROPERTY_LIST"])): ?>
                <tbody>
                <? foreach ($arResult["PROPERTY_LIST"] as $propertyID): ?>
                    <tr>
                        <td><? if (intval($propertyID) > 0): ?><?= $arResult["PROPERTY_LIST_FULL"][$propertyID]["NAME"] ?><? else: ?><?= !empty($arParams["CUSTOM_TITLE_" . $propertyID]) ? $arParams["CUSTOM_TITLE_" . $propertyID] : GetMessage("IBLOCK_FIELD_" . $propertyID) ?><? endif ?><? if (in_array($propertyID, $arResult["PROPERTY_REQUIRED"])): ?>
                                <span class="starrequired">*</span><? endif ?></td>
                        <td>
                            <?
                            if (intval($propertyID) > 0) {
                                if (
                                    $arResult["PROPERTY_LIST_FULL"][$propertyID]["PROPERTY_TYPE"] == "T"
                                    &&
                                    $arResult["PROPERTY_LIST_FULL"][$propertyID]["ROW_COUNT"] == "1"
                                )
                                    $arResult["PROPERTY_LIST_FULL"][$propertyID]["PROPERTY_TYPE"] = "S";
                                elseif (
                                    (
                                        $arResult["PROPERTY_LIST_FULL"][$propertyID]["PROPERTY_TYPE"] == "S"
                                        ||
                                        $arResult["PROPERTY_LIST_FULL"][$propertyID]["PROPERTY_TYPE"] == "N"
                                    )
                                    &&
                                    $arResult["PROPERTY_LIST_FULL"][$propertyID]["ROW_COUNT"] > "1"
                                )
                                    $arResult["PROPERTY_LIST_FULL"][$propertyID]["PROPERTY_TYPE"] = "T";
                            } elseif (($propertyID == "TAGS") && CModule::IncludeModule('search'))
                                $arResult["PROPERTY_LIST_FULL"][$propertyID]["PROPERTY_TYPE"] = "TAGS";

                            if ($arResult["PROPERTY_LIST_FULL"][$propertyID]["MULTIPLE"] == "Y") {
                                $inputNum = ($arParams["ID"] > 0 || count($arResult["ERRORS"]) > 0) ? count($arResult["ELEMENT_PROPERTIES"][$propertyID]) : 0;
                                $inputNum += $arResult["PROPERTY_LIST_FULL"][$propertyID]["MULTIPLE_CNT"];
                            } else {
                                $inputNum = 1;
                            }

                            if ($arResult["PROPERTY_LIST_FULL"][$propertyID]["GetPublicEditHTML"])
                                $INPUT_TYPE = "USER_TYPE";
                            else
                                $INPUT_TYPE = $arResult["PROPERTY_LIST_FULL"][$propertyID]["PROPERTY_TYPE"];

                            switch ($INPUT_TYPE):
                                case "USER_TYPE":
                                    for ($i = 0; $i < $inputNum; $i++) {
                                        if ($arParams["ID"] > 0 || count($arResult["ERRORS"]) > 0) {
                                            $value = intval($propertyID) > 0 ? $arResult["ELEMENT_PROPERTIES"][$propertyID][$i]["~VALUE"] : $arResult["ELEMENT"][$propertyID];
                                            $description = intval($propertyID) > 0 ? $arResult["ELEMENT_PROPERTIES"][$propertyID][$i]["DESCRIPTION"] : "";
                                        } elseif ($i == 0) {
                                            $value = intval($propertyID) <= 0 ? "" : $arResult["PROPERTY_LIST_FULL"][$propertyID]["DEFAULT_VALUE"];
                                            $description = "";
                                        } else {
                                            $value = "";
                                            $description = "";
                                        }
                                        echo call_user_func_array($arResult["PROPERTY_LIST_FULL"][$propertyID]["GetPublicEditHTML"],
                                            array(
                                                $arResult["PROPERTY_LIST_FULL"][$propertyID],
                                                array(
                                                    "VALUE" => $value,
                                                    "DESCRIPTION" => $description,
                                                ),
                                                array(
                                                    "VALUE" => "PROPERTY[" . $propertyID . "][" . $i . "][VALUE]",
                                                    "DESCRIPTION" => "PROPERTY[" . $propertyID . "][" . $i . "][DESCRIPTION]",
                                                    "FORM_NAME" => "iblock_add",
                                                ),
                                            ));
                                        ?><br/><?
                                    }
                                    break;
                                case "TAGS":
                                    $APPLICATION->IncludeComponent(
                                        "bitrix:search.tags.input",
                                        "",
                                        array(
                                            "VALUE" => $arResult["ELEMENT"][$propertyID],
                                            "NAME" => "PROPERTY[" . $propertyID . "][0]",
                                            "TEXT" => 'size="' . $arResult["PROPERTY_LIST_FULL"][$propertyID]["COL_COUNT"] . '"',
                                        ), null, array("HIDE_ICONS" => "Y")
                                    );
                                    break;
                                case "HTML":
                                    $LHE = new CHTMLEditor;
                                    $LHE->Show(array(
                                        'name' => "PROPERTY[" . $propertyID . "][0]",
                                        'id' => preg_replace("/[^a-z0-9]/i", '', "PROPERTY[" . $propertyID . "][0]"),
                                        'inputName' => "PROPERTY[" . $propertyID . "][0]",
                                        'content' => $arResult["ELEMENT"][$propertyID],
                                        'width' => '100%',
                                        'minBodyWidth' => 350,
                                        'normalBodyWidth' => 555,
                                        'height' => '200',
                                        'bAllowPhp' => false,
                                        'limitPhpAccess' => false,
                                        'autoResize' => true,
                                        'autoResizeOffset' => 40,
                                        'useFileDialogs' => false,
                                        'saveOnBlur' => true,
                                        'showTaskbars' => false,
                                        'showNodeNavi' => false,
                                        'askBeforeUnloadPage' => true,
                                        'bbCode' => false,
                                        'siteId' => SITE_ID,
                                        'controlsMap' => array(
                                            array('id' => 'Bold', 'compact' => true, 'sort' => 80),
                                            array('id' => 'Italic', 'compact' => true, 'sort' => 90),
                                            array('id' => 'Underline', 'compact' => true, 'sort' => 100),
                                            array('id' => 'Strikeout', 'compact' => true, 'sort' => 110),
                                            array('id' => 'RemoveFormat', 'compact' => true, 'sort' => 120),
                                            array('id' => 'Color', 'compact' => true, 'sort' => 130),
                                            array('id' => 'FontSelector', 'compact' => false, 'sort' => 135),
                                            array('id' => 'FontSize', 'compact' => false, 'sort' => 140),
                                            array('separator' => true, 'compact' => false, 'sort' => 145),
                                            array('id' => 'OrderedList', 'compact' => true, 'sort' => 150),
                                            array('id' => 'UnorderedList', 'compact' => true, 'sort' => 160),
                                            array('id' => 'AlignList', 'compact' => false, 'sort' => 190),
                                            array('separator' => true, 'compact' => false, 'sort' => 200),
                                            array('id' => 'InsertLink', 'compact' => true, 'sort' => 210),
                                            array('id' => 'InsertImage', 'compact' => false, 'sort' => 220),
                                            array('id' => 'InsertVideo', 'compact' => true, 'sort' => 230),
                                            array('id' => 'InsertTable', 'compact' => false, 'sort' => 250),
                                            array('separator' => true, 'compact' => false, 'sort' => 290),
                                            array('id' => 'Fullscreen', 'compact' => false, 'sort' => 310),
                                            array('id' => 'More', 'compact' => true, 'sort' => 400)
                                        ),
                                    ));
                                    break;
                                case "T":
                                    for ($i = 0; $i < $inputNum; $i++) {

                                        if ($arParams["ID"] > 0 || count($arResult["ERRORS"]) > 0) {
                                            $value = intval($propertyID) > 0 ? $arResult["ELEMENT_PROPERTIES"][$propertyID][$i]["VALUE"] : $arResult["ELEMENT"][$propertyID];
                                        } elseif ($i == 0) {
                                            $value = intval($propertyID) > 0 ? "" : $arResult["PROPERTY_LIST_FULL"][$propertyID]["DEFAULT_VALUE"];
                                        } else {
                                            $value = "";
                                        }
                                        ?>
                                        <textarea
                                                cols="<?= $arResult["PROPERTY_LIST_FULL"][$propertyID]["COL_COUNT"] ?>"
                                                rows="<?= $arResult["PROPERTY_LIST_FULL"][$propertyID]["ROW_COUNT"] ?>"
                                                name="PROPERTY[<?= $propertyID ?>][<?= $i ?>]"><?= $value ?></textarea>
                                        <?
                                    }
                                    break;

                                case "S":
                                case "N":
                                    for ($i = 0; $i < $inputNum; $i++) {
                                        if ($arParams["ID"] > 0 || count($arResult["ERRORS"]) > 0) {
                                            $value = intval($propertyID) > 0 ? $arResult["ELEMENT_PROPERTIES"][$propertyID][$i]["VALUE"] : $arResult["ELEMENT"][$propertyID];
                                        } elseif ($i == 0) {
                                            $value = intval($propertyID) <= 0 ? "" : $arResult["PROPERTY_LIST_FULL"][$propertyID]["DEFAULT_VALUE"];

                                        } else {
                                            $value = "";
                                        }
                                        ?>
                                        <input type="text" name="PROPERTY[<?= $propertyID ?>][<?= $i ?>]"
                                               size="<?= $arResult["PROPERTY_LIST_FULL"][$propertyID]["COL_COUNT"]; ?>"
                                               value="<?= $value ?>"/><br/><?
                                        if ($arResult["PROPERTY_LIST_FULL"][$propertyID]["USER_TYPE"] == "DateTime"):?><?
                                            $APPLICATION->IncludeComponent(
                                                'bitrix:main.calendar',
                                                '',
                                                array(
                                                    'FORM_NAME' => 'iblock_add',
                                                    'INPUT_NAME' => "PROPERTY[" . $propertyID . "][" . $i . "]",
                                                    'INPUT_VALUE' => $value,
                                                ),
                                                null,
                                                array('HIDE_ICONS' => 'Y')
                                            );
                                            ?><br/>
                                            <small><?= GetMessage("IBLOCK_FORM_DATE_FORMAT") ?><?= FORMAT_DATETIME ?></small><?
                                        endif
                                        ?><br/><?
                                    }
                                    break;

                                case "F":
                                    for ($i = 0; $i < $inputNum; $i++) {
                                        $value = intval($propertyID) > 0 ? $arResult["ELEMENT_PROPERTIES"][$propertyID][$i]["VALUE"] : $arResult["ELEMENT"][$propertyID];
                                        ?>
                                        <input type="hidden"
                                               name="PROPERTY[<?= $propertyID ?>][<?= $arResult["ELEMENT_PROPERTIES"][$propertyID][$i]["VALUE_ID"] ? $arResult["ELEMENT_PROPERTIES"][$propertyID][$i]["VALUE_ID"] : $i ?>]"
                                               value="<?= $value ?>"/>
                                        <input type="file"
                                               size="<?= $arResult["PROPERTY_LIST_FULL"][$propertyID]["COL_COUNT"] ?>"
                                               name="PROPERTY_FILE_<?= $propertyID ?>_<?= $arResult["ELEMENT_PROPERTIES"][$propertyID][$i]["VALUE_ID"] ? $arResult["ELEMENT_PROPERTIES"][$propertyID][$i]["VALUE_ID"] : $i ?>"/>
                                        <br/>
                                        <?

                                        if (!empty($value) && is_array($arResult["ELEMENT_FILES"][$value])) {
                                            ?>
                                            <input type="checkbox"
                                                   name="DELETE_FILE[<?= $propertyID ?>][<?= $arResult["ELEMENT_PROPERTIES"][$propertyID][$i]["VALUE_ID"] ? $arResult["ELEMENT_PROPERTIES"][$propertyID][$i]["VALUE_ID"] : $i ?>]"
                                                   id="file_delete_<?= $propertyID ?>_<?= $i ?>" value="Y"/><label
                                                    for="file_delete_<?= $propertyID ?>_<?= $i ?>"><?= GetMessage("IBLOCK_FORM_FILE_DELETE") ?></label>
                                            <br/>
                                            <?

                                            if ($arResult["ELEMENT_FILES"][$value]["IS_IMAGE"]) {
                                                ?>
                                                <img src="<?= $arResult["ELEMENT_FILES"][$value]["SRC"] ?>"
                                                     height="<?= $arResult["ELEMENT_FILES"][$value]["HEIGHT"] ?>"
                                                     width="<?= $arResult["ELEMENT_FILES"][$value]["WIDTH"] ?>"
                                                     border="0"/><br/>
                                                <?
                                            } else {
                                                ?>
                                                <?= GetMessage("IBLOCK_FORM_FILE_NAME") ?>: <?= $arResult["ELEMENT_FILES"][$value]["ORIGINAL_NAME"] ?>
                                                <br/>
                                                <?= GetMessage("IBLOCK_FORM_FILE_SIZE") ?>: <?= $arResult["ELEMENT_FILES"][$value]["FILE_SIZE"] ?> b
                                                <br/>
                                                [
                                                <a href="<?= $arResult["ELEMENT_FILES"][$value]["SRC"] ?>"><?= GetMessage("IBLOCK_FORM_FILE_DOWNLOAD") ?></a>]
                                                <br/>
                                                <?
                                            }
                                        }
                                    }

                                    break;
                                case "L":

                                    if ($arResult["PROPERTY_LIST_FULL"][$propertyID]["LIST_TYPE"] == "C")
                                        $type = $arResult["PROPERTY_LIST_FULL"][$propertyID]["MULTIPLE"] == "Y" ? "checkbox" : "radio";
                                    else
                                        $type = $arResult["PROPERTY_LIST_FULL"][$propertyID]["MULTIPLE"] == "Y" ? "multiselect" : "dropdown";

                                    switch ($type):
                                        case "checkbox":
                                        case "radio":
                                            foreach ($arResult["PROPERTY_LIST_FULL"][$propertyID]["ENUM"] as $key => $arEnum) {
                                                $checked = false;
                                                if ($arParams["ID"] > 0 || count($arResult["ERRORS"]) > 0) {
                                                    if (is_array($arResult["ELEMENT_PROPERTIES"][$propertyID])) {
                                                        foreach ($arResult["ELEMENT_PROPERTIES"][$propertyID] as $arElEnum) {
                                                            if ($arElEnum["VALUE"] == $key) {
                                                                $checked = true;
                                                                break;
                                                            }
                                                        }
                                                    }
                                                } else {
                                                    if ($arEnum["DEF"] == "Y") $checked = true;
                                                }

                                                ?>
                                                <input type="<?= $type ?>"
                                                       name="PROPERTY[<?= $propertyID ?>]<?= $type == "checkbox" ? "[" . $key . "]" : "" ?>"
                                                       value="<?= $key ?>"
                                                       id="property_<?= $key ?>"<?= $checked ? " checked=\"checked\"" : "" ?> />
                                                <label for="property_<?= $key ?>"><?= $arEnum["VALUE"] ?></label><br/>
                                                <?
                                            }
                                            break;

                                        case "dropdown":
                                        case "multiselect":
                                            ?>
                                            <select name="PROPERTY[<?= $propertyID ?>]<?= $type == "multiselect" ? "[]\" size=\"" . $arResult["PROPERTY_LIST_FULL"][$propertyID]["ROW_COUNT"] . "\" multiple=\"multiple" : "" ?>">
                                                <option value=""><? echo GetMessage("CT_BIEAF_PROPERTY_VALUE_NA") ?></option>
                                                <?
                                                if (intval($propertyID) > 0) $sKey = "ELEMENT_PROPERTIES";
                                                else $sKey = "ELEMENT";

                                                foreach ($arResult["PROPERTY_LIST_FULL"][$propertyID]["ENUM"] as $key => $arEnum) {
                                                    $checked = false;
                                                    if ($arParams["ID"] > 0 || count($arResult["ERRORS"]) > 0) {
                                                        foreach ($arResult[$sKey][$propertyID] as $elKey => $arElEnum) {
                                                            if ($key == $arElEnum["VALUE"]) {
                                                                $checked = true;
                                                                break;
                                                            }
                                                        }
                                                    } else {
                                                        if ($arEnum["DEF"] == "Y") $checked = true;
                                                    }
                                                    ?>
                                                    <option value="<?= $key ?>" <?= $checked ? " selected=\"selected\"" : "" ?>><?= $arEnum["VALUE"] ?></option>
                                                    <?
                                                }
                                                ?>
                                            </select>
                                            <?
                                            break;

                                    endswitch;
                                    break;
                            endswitch; ?>
                        </td>
                    </tr>
                <? endforeach; ?>
                <? if ($arParams["USE_CAPTCHA"] == "Y" && $arParams["ID"] <= 0): ?>
                    <tr>
                        <td><?= GetMessage("IBLOCK_FORM_CAPTCHA_TITLE") ?></td>
                        <td>
                            <input type="hidden" name="captcha_sid" value="<?= $arResult["CAPTCHA_CODE"] ?>"/>
                            <img src="/bitrix/tools/captcha.php?captcha_sid=<?= $arResult["CAPTCHA_CODE"] ?>"
                                 width="180" height="40" alt="CAPTCHA"/>
                        </td>
                    </tr>
                    <tr>
                        <td><?= GetMessage("IBLOCK_FORM_CAPTCHA_PROMPT") ?><span class="starrequired">*</span>:</td>
                        <td><input type="text" name="captcha_word" maxlength="50" value=""></td>
                    </tr>
                <? endif ?>
                </tbody>
            <? endif ?>
            <tfoot>
            <tr>
                <td colspan="2">
                    <input type="submit" name="iblock_submit" value="<?= GetMessage("IBLOCK_FORM_SUBMIT") ?>"/>
                    <? if ($arParams["LIST_URL"] <> ''): ?>
                        <input type="submit" name="iblock_apply" value="<?= GetMessage("IBLOCK_FORM_APPLY") ?>"/>
                        <input
                                type="button"
                                name="iblock_cancel"
                                value="<? echo GetMessage('IBLOCK_FORM_CANCEL'); ?>"
                                onclick="location.href='<? echo CUtil::JSEscape($arParams["LIST_URL"]) ?>';"
                        >
                    <? endif ?>
                </td>
            </tr>
            </tfoot>
        </table>
    </form>
<?php endif; ?>
