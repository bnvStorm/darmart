<?php if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
use Bitrix\Main\Application;
use Bitrix\Main\Diag\Debug;
use Bitrix\Iblock\ElementTable;
\Bitrix\Main\Loader::includeModule('sale');

$request = Application::getInstance()->getContext()->getRequest();

$arResult['ORDER_ID'] = $request->getQuery('order_id');
$arResult['PRODUCT_INFO'] = [];

$productId = $request->getQuery('product_id');
$orderId = $request->getQuery('order_id');

/*$product = ElementTable::getList([
    'select' => ['*'],
    'filter' => ['ID' => $productId]
]);*/

$order = Bitrix\Sale\Order::getList([
    'select' => [
        '*',
        //'PRODUCT_' => 'BASKET.PRODUCT',
        'BASKET_' => 'BASKET'
        //'ELEMENT_' => 'BASKET.PRODUCT.IBLOCK'
    ],
    'filter' => [
        'ID' => $orderId,
        //'BASKET.PRODUCT.ID' => $productId
        'BASKET.PRODUCT_ID' => $productId
    ],
    'limit' => 1
]);
$user = CUser::GetByID($USER->GetID())->Fetch();

$arResult['USER_INFO'] = $user;

if($order->getSelectedRowsCount() != 0){
    $arResult['ORDER_INFO'] = $order->fetch();
    $arResult['ORDER_INFO']['DATE'] = $arResult['ORDER_INFO']['DATE_INSERT']->toString();
}
/*if($product->getSelectedRowsCount() != 0){
    $arResult['PRODUCT_INFO'] = $product->fetch();
}*/

if(!$arResult['ORDER_INFO'])
    $arResult['ERRORS'][] = 'Заказ не найден';
