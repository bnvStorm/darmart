<?
$MESS['PROFILE_DATA_SAVED'] = "Изменения сохранены";
$MESS['LAST_UPDATE'] = "Дата обновления:";
$MESS['ACTIVE'] = "Активен:";
$MESS['NAME'] = "Имя:";
$MESS['LAST_NAME'] = "Фамилия:";
$MESS['SECOND_NAME'] = "Отчество:";
$MESS['EMAIL'] = "E-Mail:";
$MESS['MAIN_RESET'] = "Назад";
$MESS['LOGIN'] = "Логин (мин. 3 символа):";
$MESS['NEW_PASSWORD'] = "Пароль";
$MESS['NEW_PASSWORD_CONFIRM'] = "Подтвердить";
$MESS['SAVE'] = "Сохранить изменения";
$MESS['RESET'] = "Сбросить";
$MESS['LAST_LOGIN'] = "Последняя авторизация:";
$MESS['NEW_PASSWORD_REQ'] = "Новый пароль:";
$MESS['PERSONAL_PHONE'] = "Телефон";
$MESS['MAIN_SAVE'] = "Продолжить";
$MESS['TITLE'] = 'Смена пароля';
$MESS['PASSWORD_CHANGE_DISABLED_ERROR'] = 'Вы не можете сменить пароль';
$MESS['UPDATE_SUCCESS'] = 'Ваш пароль успешно изменен!';

