<?php

$MESS['PAGE_TITLE'] = 'My favorites';
