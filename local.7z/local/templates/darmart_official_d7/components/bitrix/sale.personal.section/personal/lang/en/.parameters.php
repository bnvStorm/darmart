<?php

$MESS['SHOW_FAVORITES_PAGE'] = 'Show favorite page';
$MESS['PATH_TO_FAVORITES'] = 'Path to favorites page';
$MESS['CHANGE_PASSWORD_URL'] = 'Change password page';
$MESS['SHOW_CHANGE_PASSWORD_PAGE'] = 'Show change password page';
$MESS['FAVORITES_URL'] = 'Favorites page';
