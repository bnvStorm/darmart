<?
$MESS ['CT_BSS_NO_RUBRICS_FOUND'] = "There is no newsletter category found.";
$MESS ['CT_BSS_TEXT'] = "Text";
$MESS ['CT_BSS_HTML'] = "HTML";
$MESS ['SUBMIT'] = "Continue";
$MESS ['BACK'] = 'Back';
$MESS ['SUBSCRIBE'] = 'Subscribe';
$MESS ['YES'] = 'Yes';
$MESS ['NO'] = 'No';
$MESS['UPDATE_SUCCESS'] = 'You subscription was successfully updated!';
?>
