<?php

$MESS['PAGE_TITLE'] = 'Мои закладки';
