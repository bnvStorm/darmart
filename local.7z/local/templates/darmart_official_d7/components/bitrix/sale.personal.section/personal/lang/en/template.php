<?
$MESS["SPS_ACCOUNT_PAGE_NAME"] = "Personal account";
$MESS["SPS_PERSONAL_PAGE_NAME"] = "Personal information";
$MESS["SPS_PROFILE_PAGE_NAME"] = "Order profiles";
$MESS["SPS_ORDER_PAGE_NAME"] = "Current orders";
$MESS["SPS_ORDER_PAGE_HISTORY"] = "Order history";
$MESS["SPS_SUBSCRIBE_PAGE_NAME"] = "Subscriptions";
$MESS["SPS_BASKET_PAGE_NAME"] = "Shopping cart";
$MESS["SPS_CONTACT_PAGE_NAME"] = "Contacts";
$MESS["SPS_ERROR_NOT_CHOSEN_ELEMENT"] = "No items selected";
$MESS["SPS_CHAIN_MAIN"] = "My account";
$MESS["TITLE_MAIN"] = "Personal area";
$MESS["TITLE_ORDERS"] = "My orders";
$MESS['TITLE_SUBSCRIBE'] = 'Subscribe';
$MESS["FAVORITES_PAGE"] = "Change favorites";
$MESS["CHANGE_PASSWORD_PAGE"] = "Change password";
?>
