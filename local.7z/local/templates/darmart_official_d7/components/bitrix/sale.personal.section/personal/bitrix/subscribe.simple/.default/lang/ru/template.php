<?
$MESS ['CT_BSS_NO_RUBRICS_FOUND'] = "Не найдено ни одной рубрики подписки.";
$MESS ['CT_BSS_TEXT'] = "Текст";
$MESS ['CT_BSS_HTML'] = "HTML";
$MESS ['SUBMIT'] = "Продолжить";
$MESS ['BACK'] = 'Назад';
$MESS ['SUBSCRIBE'] = 'Подписаться';
$MESS ['YES'] = 'Да';
$MESS ['NO'] = 'Нет';
$MESS['UPDATE_SUCCESS'] = 'Ваша подписка успешно обновлена!';
?>
