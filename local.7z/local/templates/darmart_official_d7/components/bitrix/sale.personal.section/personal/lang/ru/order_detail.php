<?php
$MESS["SPS_CHAIN_MAIN"] = "Мой кабинет";
$MESS["SPS_CHAIN_ORDERS"] = "Мои заказы";
$MESS["SPS_CHAIN_ORDER_DETAIL"] = "Информация о заказе №#ID#";