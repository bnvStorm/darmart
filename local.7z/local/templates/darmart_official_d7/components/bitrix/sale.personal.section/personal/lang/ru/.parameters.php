<?php

$MESS['SHOW_FAVORITES_PAGE'] = 'Показать страницу избранных';
$MESS['PATH_TO_FAVORITES'] = 'Путь к странице избранных';
$MESS['CHANGE_PASSWORD_URL'] = 'Страница смены пароля';
$MESS['SHOW_CHANGE_PASSWORD_PAGE'] = 'Показывать страницу смены пароля';
$MESS['FAVORITES_URL'] = 'Страница избранных';
