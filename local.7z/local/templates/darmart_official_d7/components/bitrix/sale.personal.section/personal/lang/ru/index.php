<?php
$MESS["SPS_ACCOUNT_PAGE_NAME"] = "Личный счет";
$MESS["SPS_PERSONAL_PAGE_NAME"] = "Личные данные";
$MESS["SPS_PROFILE_PAGE_NAME"] = "Профили заказов";
$MESS["SPS_ORDER_PAGE_NAME"] = "Текущие заказы";
$MESS["SPS_ORDER_PAGE_HISTORY"] = "История заказов";
$MESS["SPS_SUBSCRIBE_PAGE_NAME"] = "Подписки";
$MESS["SPS_BASKET_PAGE_NAME"] = "Корзина";
$MESS["SPS_CONTACT_PAGE_NAME"] = "Контакты";
$MESS["SPS_ERROR_NOT_CHOSEN_ELEMENT"] = "Отсутвуют выбранные элементы";
$MESS["SPS_CHAIN_MAIN"] = "Мой кабинет";
$MESS["SPS_TITLE_MAIN"] = "Персональный раздел";


