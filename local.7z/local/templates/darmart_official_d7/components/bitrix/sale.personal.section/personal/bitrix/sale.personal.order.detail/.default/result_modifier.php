<?php if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
foreach($arResult['BASKET'] as $key => $item){
    $canReturn = false;

    $returns = CIBlockElement::GetList(
        [],
        [
            'PROPERTY_PRODUCTS.ID' => $item['PRODUCT_ID'],
            'PROPERTY_USER.ID' => $USER->GetID()
        ],
        false,
        false,
        []
    );

    if($returns->SelectedRowsCount() == 0){
        $returnUrl = "/personal/return_order/?order_id={$arResult['ID']}&product_id={$item['PRODUCT_ID']}&item_id={$item['ID']}";
        $arResult['BASKET'][$key]['URL_TO_RETURN'] = $returnUrl;
        $canReturn = true;
    }

    $arResult['BASKET'][$key]['CAN_RETURN'] = $canReturn;
}
