<?
$MESS ['TP_BSF_USE_SUGGEST'] = "Show search phrase prompts";
?>