<?
$MESS["CP_SBB_TPL_COLUMNS_LIST_MOBILE"] = "Колонки, отображаемые на мобильных устройствах";
$MESS["CP_SBB_TPL_PROPERTIES_RECALCULATE_BASKET"] = "Свойства, влияющие на пересчет корзины";
$MESS["CP_SBB_TPL_THEME_SITE"] = "Брать тему из настроек сайта (для решения bitrix.eshop)";
$MESS["CP_SBB_TPL_THEME_BLUE"] = "Синяя (тема по умолчанию)";
$MESS["CP_SBB_TPL_THEME_GREEN"] = "Зеленая";
$MESS["CP_SBB_TPL_THEME_RED"] = "Красная";
$MESS["CP_SBB_TPL_THEME_YELLOW"] = "Желтая";
$MESS["CP_SBB_TPL_DEFERRED_REFRESH"] = "Использовать механизм отложенной актуализации данных товаров с провайдером";
$MESS["CP_SBB_TPL_SHOW_RESTORE"] = "Разрешить восстановление удалённых товаров";
$MESS["CP_SBB_EMPTY_BASKET_HINT_PATH"] = "Путь к странице для продолжения покупок";
$MESS["CP_SBB_TPL_TEMPLATE_THEME"] = "Цветовая тема";
$MESS["CP_SBB_TPL_TOTAL_BLOCK_DISPLAY"] = "Отображение блока с общей информацией по корзине";
$MESS["CP_SBB_TPL_TOTAL_BLOCK_DISPLAY_TOP"] = "Над корзиной";
$MESS["CP_SBB_TPL_TOTAL_BLOCK_DISPLAY_BOTTOM"] = "Под корзиной";
$MESS["CP_SBB_TPL_USE_DYNAMIC_SCROLL"] = "Использовать динамическую подгрузку товаров";
$MESS["CP_SBB_TPL_SHOW_FILTER"] = "Отображать фильтр товаров";
$MESS["SHOW_FILTER_TIP"] = "Для мобильных устройств фильтр не отображается.";
$MESS["CP_SBB_TPL_DISPLAY_MODE"] = "Режим отображения корзины";
$MESS["CP_SBB_TPL_DISPLAY_MODE_EXTENDED"] = "Расширенный";
$MESS["CP_SBB_TPL_DISPLAY_MODE_COMPACT"] = "Компактный";
$MESS["CP_SBB_TPL_PRICE_DISPLAY_MODE"] = "Отображать цену в отдельной колонке";
$MESS["CP_SBB_TPL_PRODUCT_BLOCKS_ORDER"] = "Порядок отображения блоков товара";
$MESS["CP_SBB_TPL_USE_PRICE_ANIMATION"] = "Использовать анимацию цен";
$MESS["CP_SBB_TPL_LABEL_PROP"] = "Свойства меток товара";
$MESS["CP_SBB_TPL_LABEL_PROP_MOBILE"] = "Свойства меток товара, отображаемые на мобильных устройствах";
$MESS["CP_SBB_TPL_LABEL_PROP_POSITION"] = "Расположение меток товара";
$MESS["CP_SBB_TPL_SHOW_DISCOUNT_PERCENT"] = "Показывать процент скидки рядом с изображением";
$MESS["CP_SBB_TPL_DISCOUNT_PERCENT_POSITION"] = "Расположение процента скидки";
$MESS["CP_SBB_TPL_PRODUCT_BLOCK_PROPERTIES"] = "Свойства корзины";
$MESS["CP_SBB_TPL_PRODUCT_BLOCK_SKU"] = "Торговое предложение";
$MESS["CP_SBB_TPL_PRODUCT_BLOCK_COLUMNS"] = "Свойства товара";
$MESS["CP_SBB_TPL_USE_ENHANCED_ECOMMERCE"] = "Отправлять данные электронной торговли в Google и Яндекс";
$MESS["USE_ENHANCED_ECOMMERCE_TIP"] = "Требуется дополнительная настройка в Google Analytics Enhanced 
Ecommerce и/или Яндекс.Метрике";
$MESS["CP_SBB_TPL_DATA_LAYER_NAME"] = "Имя контейнера данных";
$MESS["CP_SBB_TPL_BRAND_PROPERTY"] = "Свойство брендов";
$MESS["EMPTY_BASKET_HINT_PATH_TIP"] = "Ссылка для продолжения покупок отображается в случае если корзина пуста.<br>При условии, что путь пустой, текст не будет отображен.";

?>