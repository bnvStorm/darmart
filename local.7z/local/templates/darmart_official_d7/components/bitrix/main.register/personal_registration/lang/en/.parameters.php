<?
$MESS ['USER_PROPERTY_NAME'] = "User properties section title";
?>