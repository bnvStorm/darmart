<?php

$MESS['FORGOT_PASSWORD_TITLE'] = 'Забыли пароль?';
$MESS ['AUTH_FORGOT_PASSWORD_2'] = "Введите адрес электронной почты вашей учетной записи. Нажмите кнопку Продолжить, чтобы получить пароль по электронной почте.";
$MESS['FORGOT_PASSWORD_EMAIL'] = 'Ваш E-Mail';
$MESS['BACK_BTN'] = 'Назад';
$MESS['SUBMIT_BTN'] = 'Продолжить';
$MESS ['AUTH_GET_CHECK_STRING'] = "Выслать контрольную строку";
$MESS ['AUTH_SEND'] = "Выслать";
$MESS ['AUTH_AUTH'] = "Авторизация";
$MESS["AUTH_LOGIN_EMAIL"] = "Логин или email";
$MESS["system_auth_captcha"] = "Введите символы с картинки";
$MESS["forgot_pass_email_note"] = "Контрольная строка для смены пароля, а также ваши регистрационные данные, будут высланы вам на email.";
$MESS["forgot_pass_phone_number"] = "Номер телефона";
$MESS["forgot_pass_phone_number_note"] = "На ваш номер телефона будет выслано СМС с кодом для смены пароля.";
?>
