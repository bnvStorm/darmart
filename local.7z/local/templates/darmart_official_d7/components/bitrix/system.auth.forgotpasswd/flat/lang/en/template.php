<?php

$MESS['FORGOT_PASSWORD_TITLE'] = 'Forgot your password?';
$MESS['FORGOT_PASSWORD_EMAIL_TITLE'] = 'Your email';
$MESS['FORGOT_PASSWORD_EMAIL'] = 'E-Mail:';
$MESS["AUTH_AUTH"] = "Authorization";
$MESS['BACK_BTN'] = 'Back';
$MESS['SUBMIT_BTN'] = 'Continue';
$MESS["AUTH_FORGOT_PASSWORD_2"] = "Select password change method:";
$MESS["AUTH_GET_CHECK_STRING"] = "Get check string";
$MESS["AUTH_LOGIN_EMAIL"] = "Login or E-mail";
$MESS["AUTH_SEND"] = "Send";
$MESS["forgot_pass_email_note"] = "Your account info will be sent to you by email.";
$MESS["forgot_pass_phone_number"] = "Phone number";
$MESS["forgot_pass_phone_number_note"] = "A code to change your password will be texted to your phone.";
$MESS["system_auth_captcha"] = "Enter the characters you see on the picture";
?>
