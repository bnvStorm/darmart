<?
$MESS["CATALOG_PERSONAL_RECOM"] = "Персональные рекомендации";