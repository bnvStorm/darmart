<? if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die(); ?>

<? if (!empty($arResult)): ?>
    <aside id="column-left" class="col-sm-3 hidden-xs">
        <div class="list-group">
            <?
            $previousLevel = 0;
            foreach ($arResult as $arItem):?>

                <? if ($previousLevel && $arItem["DEPTH_LEVEL"] < $previousLevel):?>
                    <?= str_repeat("", ($previousLevel - $arItem["DEPTH_LEVEL"])); ?>
                <? endif ?>

                <? if ($arItem["IS_PARENT"]):?>

                    <? if ($arItem["DEPTH_LEVEL"] == 1):?>
                        <a href="<?= $arItem["LINK"] ?>"
                           class="<? if ($arItem["SELECTED"]):?>list-group-item<? else:?>list-group-item<? endif ?>"><?= $arItem["TEXT"] ?></a>
                    <? else:?>
                        <a href="<?= $arItem["LINK"] ?>"
                           class="<? if ($arItem["SELECTED"]):?>list-group-item parent<? else:?>list-group-item parent<? endif ?>"><i
                                    class="pe-7s-angle-right"></i> <?= $arItem["TEXT"] ?></a>

                    <? endif ?>

                <? else:?>
                    <? if ($arItem["DEPTH_LEVEL"] == 1):?>
                        <a href="<?= $arItem["LINK"] ?>"
                           class="<? if ($arItem["SELECTED"]):?>list-group-item<? else:?>list-group-item<? endif ?>"
                           title="<?= GetMessage("MENU_ITEM_ACCESS_DENIED") ?>"><?= $arItem["TEXT"] ?></a></li>
                    <? else:?>
                        <a href="<?= $arItem["LINK"] ?>" class="<? if ($arItem["SELECTED"]):?>list-group-item<? else:?>list-group-item<? endif ?>"
                           title="<?= GetMessage("MENU_ITEM_ACCESS_DENIED") ?>"><i
                                    class="pe-7s-angle-right"></i> <?= $arItem["TEXT"] ?></a>
                    <? endif ?>
                <? endif ?>

                <? $previousLevel = $arItem["DEPTH_LEVEL"]; ?>

            <? endforeach ?>

            <? if ($previousLevel > 1)://close last item tags?>
                <?= str_repeat("", ($previousLevel - 1)); ?>
            <? endif ?>

        </div>
    </aside>
<? endif ?>


