<?php

namespace Rating1C\Darmart\Users;

class User
{

}
