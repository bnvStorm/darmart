<?php

namespace Rating1C\Damart\User;

use Bitrix\Main\Diag\Debug;

if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();

class UserEventHandler{

    public static function onBeforeUserUpdate(&$fields){

    }

}
