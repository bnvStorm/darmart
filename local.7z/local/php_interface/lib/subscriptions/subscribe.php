<?php

namespace Rating1C\Darmart\Subscriptions;

if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();

class Subscribe
{
    public $newsRubricId = 1;
}
