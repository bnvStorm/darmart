<?
$MESS ['MFT_YES'] = "Да";
$MESS ['MFT_NO'] = "Нет";
$MESS ['MFT_NAME'] = "Имя";
$MESS ['MFT_LASTNAME'] = "Фамилия";
$MESS ['MFT_EMAIL'] = "E-mail";
$MESS ['MFT_PHONE'] = "Телефон";
$MESS ['MFT_NUMBER'] = "№ заказа";
$MESS ['MFT_DATE'] = "Дата заказа";
$MESS ['MFT_INFO'] = "Информация о товаре и причина возврата";
$MESS ['MFT_NAME_ORDER'] = "Наименование";
$MESS ['MFT_MODEL'] = "Модель";
$MESS ['MFT_QUANTITY'] = "Количество";
$MESS ['MFT_CAUSE'] = "Причина";
$MESS ['MFT_CAUSE_VARIANT1'] = "Другое (другая причина), пожалуйста, укажите/приложите подробности";
$MESS ['MFT_CAUSE_VARIANT2'] = "Ошибочный, пожалуйста, укажите/приложите подробности";
$MESS ['MFT_CAUSE_VARIANT3'] = "Получен не тот (ошибочный) товар";
$MESS ['MFT_CAUSE_VARIANT4'] = "Получен/доставлен неисправным (сломанным)";
$MESS ['MFT_UNPACKED'] = "Распакован";
$MESS ['MFT_MESSAGE'] = "Описание";
$MESS ['MFT_CAPTCHA'] = "Защита от автоматических сообщений";
$MESS ['MFT_CAPTCHA_CODE'] = "Введите слово на картинке";
$MESS ['MFT_SUBMIT'] = "Отправить";
?>