<?
$MESS ['MAIN_FEEDBACK_COMPONENT_NAME'] = "Форма обратной связи";
$MESS ['MAIN_FEEDBACK_COMPONENT_DESCR'] = "Форма для отправки сообщения с сайта на E-mail";
?>