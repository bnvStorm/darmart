<?
$MESS ['T_IBLOCK_DESC_LIST'] = "List of news";
$MESS ['T_IBLOCK_DESC_LIST_DESC'] = "List of news of one information block";
$MESS ['T_IBLOCK_DESC_NEWS'] = "News";
?>
