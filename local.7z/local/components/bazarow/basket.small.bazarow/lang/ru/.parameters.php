<?
$MESS["SBBS_PATH_TO_BASKET"] = "Страница корзины";
$MESS["SBBS_PATH_TO_ORDER"] = "Страница оформления заказа";
$MESS["SBBS_SHOW_DELAY"] = "Показывать отложенные товары";
$MESS["SBBS_SHOW_NOTAVAIL"] = "Показывать товары, недоступные для покупки";
$MESS["SBBS_SHOW_SUBSCRIBE"] = "Показывать товары, на которые подписан покупатель";
?>