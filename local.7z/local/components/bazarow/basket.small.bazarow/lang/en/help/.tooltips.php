<?
$MESS ['PATH_TO_BASKET_TIP'] = "Specifies the path name of a basket page. You can create the basket page using the <b>Shopping Cart</b> component.";
$MESS ['PATH_TO_ORDER_TIP'] = "The path name of the order completion page. You can specify only the file name if the page is in the current directory.";
?>
