<?
$MESS ['SBBS_DEFAULT_TEMPLATE_NAME'] = "Small basket";
$MESS ['SBBS_DEFAULT_TEMPLATE_DESCRIPTION'] = "Small basket";
$MESS ['SBBS_NAME'] = "Basket";
?>