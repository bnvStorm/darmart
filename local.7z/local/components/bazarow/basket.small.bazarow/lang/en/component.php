<?
$MESS['SALE_MODULE_NOT_INSTALL'] = "e-Store module is not installed";
?>